package commonReusable;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Test extends Utilities{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		//System.setProperty("webdriver.gecko.driver",".\\drivers\\geckodriver.exe"); 
		//WebDriver driver = new FirefoxDriver(); //Creating an object of FirefoxDriver
		
		//System.setProperty("webdriver.edge.driver", ".\\drivers\\msedgedriver.exe");
		//WebDriver driver=new EdgeDriver(); 
			
		
		//System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");		
		//WebDriver driver=new ChromeDriver(); 
		
		
		//System.setProperty("webdriver.ie.driver", ".\\drivers\\IEDriverServer.exe");
		//WebDriver driver=new InternetExplorerDriver(); 
		
		    /*    defineBrowser("Firefox");
		
		
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.get("https://www.google.com/");
				driver.findElement(By.name("q")).sendKeys("Browserstack Guide"); //name locator for text box
				WebElement searchbutton = driver.findElement(By.name("btnK"));//name locator for google search
				searchbutton.click();
				
				driver.quit();*/
		
		
	}

}
