/**----------------------------------------------------------------------
Class Name: WeatherReportDefinitions
Description: This java class will collate & organize all the definitions that are to be implemented as part of 'Weather Forecast' 
Date of Creation: 14/04/2020
Extends: Internally extends to Steps java files (in built Serenity capabilities)
Implements: NA
Author: Leela, Sriram
-------------------------------------------------------------------------
Update Log: Newly designed and implemented for the technical test project
Date:14/04/2020 By:Leela, Sriram Details: No further updates
------------------------------------------------------------------------*/

package definitions;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import io.cucumber.java.en.Then;
import net.thucydides.core.annotations.Steps;
import steps.ContactSteps;
import java.text.DecimalFormat;
import org.apache.log4j.Logger;
import commonReusable.Utilities;



public class ContactDefinitions {

	
    @Steps
    ContactSteps contactSteps;
    
   
    /**----------------------------------------------------------------------
    Method Name: getDataValues()
    Description: This method is reusable and robust one that support all required test data for different test cases & features
    Date of Creation: 29/04/2020
    Input Arguments: String - testCaseName
    Return Parameters: void()
    Exception Used: e.getMessage()
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
    
    @Then("^The test data is provided for '(.*)' executions$")
	public static void getDataValues(String testCaseName) throws Exception{
		try {
			
			Utilities.testData =  Utilities.getData("PlanitTest.xls", "Testing", testCaseName);
			
		} catch (Exception e) {
			
			e.getMessage();
			
		}      			
	}
    
    
    @When("^Launch the planit testing application$")
    public void weatherDataForALocation() {
    	contactSteps.launchPlanitTestingApplication();
    }
    
    @Then("^Verify the errors on contact page$")
    public void verifyErrors() throws InterruptedException {
    	contactSteps.fromthehomepagegotocontactpage();
    	contactSteps.clickOnSubmitButton();
    	contactSteps.validateErrors();
    	contactSteps.populateMandatoryFields();
    	contactSteps.validateErrorsAreGone();
    	
    }
    
    @When("^From the home page go to contact page$")
    public void navigateToContactPage() throws InterruptedException {
    	contactSteps.fromthehomepagegotocontactpage();
    }
    
    
    @When("^Populate mandatory fields$")
    public void populateMandatoryFields() throws InterruptedException {
    	contactSteps.populateMandatoryFields();
    }
    
    
    @When("^Click on submit button$")
    public void clickOnSubmitButton() throws InterruptedException {
    	contactSteps.clickOnSubmitButton();
    }
    
    @When("^Validate successful submission message$")
    public void successfulMessage() throws InterruptedException {
    	contactSteps.verifySuccessMessage();
    }
    
    @When("^Validate error messages$")
    public void validateErrors() throws InterruptedException {
    	contactSteps.validateInvalidErrors();
    }
    
      
    @When("^Click on Shop link$")
    public void navigateToShopPage() throws InterruptedException {
    	contactSteps.ClickOnElement("Shop");
    }
   
    
    @When("^Verify the items are in the cart$")
    public void verifyItemsInCart() throws InterruptedException {
    	contactSteps.buyItems();
    	contactSteps.ClickOnElement("Cart");
    	contactSteps.verifyCartItems();
    }
}
