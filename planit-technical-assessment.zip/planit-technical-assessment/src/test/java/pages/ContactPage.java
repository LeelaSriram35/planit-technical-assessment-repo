package pages;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.map.HashedMap;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.thoughtworks.xstream.mapper.PackageAliasingMapper;

import commonReusable.Utilities;
import net.serenitybdd.core.pages.PageObject;

public class ContactPage extends PageObject {

	Utilities util;

	static WebDriver driver;

	public ContactPage(WebDriver driver) {
		this.driver = driver;
	}

	private static HashMap<String, String> pageMap;

	static {

		pageMap = new HashMap<>();

		pageMap.put("contact", "//a[text()='Contact']");
		pageMap.put("submit", "//a[text()='Submit']");
		pageMap.put("foreNameError", "//span[text()='Forename is required']");
		pageMap.put("emailError", "//span[text()='Email is required']");
		pageMap.put("messageError", "//span[text()='Message is required']");

		pageMap.put("forename", "//input[@id='forename']");
		pageMap.put("email", "//input[@id='email']");
		pageMap.put("message", "//textarea[@id='message']");
		pageMap.put("successMsg", "//strong[text()='Thanks " + Utilities.testData.get("Forename") + "']");
		pageMap.put("successMsg1", "//div/strong/following::text()[1]");
		pageMap.put("validEmail", "//span[text()='Please enter a valid email']");
		pageMap.put("Shop", "//a[text()='Shop']");
		pageMap.put("Cart", "//*[@id='nav-cart']/a");
		pageMap.put("", "");
		pageMap.put("", "");
		pageMap.put("", "");

	}

	public String getData(String getDataFor) {

		return util.testData.get(getDataFor);

	}

	public void launchApplication() {
		getDriver().manage().window().maximize();
		getDriver().manage().deleteAllCookies();
		getDriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Utilities.launchApplication(getDriver(), getData("Url"));

	}

	public void clickElement(String element) throws InterruptedException {
		Utilities.click(getDriver(), pageMap.get(element));

	}

	public void elementIsDisplayed(String element) throws InterruptedException {

		getDriver().findElement(By.xpath(pageMap.get(element))).isDisplayed();

	}

	public void enterValueInto(String element, String value) throws InterruptedException {

		getDriver().findElement(By.xpath(pageMap.get(element))).sendKeys(value);
		Thread.sleep(2000);

	}

	public void elementNotToDisplayed(String element) throws InterruptedException {

		Utilities.waitDForElementToDisappear(getDriver(), pageMap.get(element));

	}

	public void verifySuccessMessage(String element) throws InterruptedException {

		Assert.assertTrue("The expected success message is not displayed",
				getDriver().findElement(By.xpath(pageMap.get(element))).isDisplayed());

	}

}
