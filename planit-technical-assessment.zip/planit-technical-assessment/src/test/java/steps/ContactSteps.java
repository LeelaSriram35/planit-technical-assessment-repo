/**----------------------------------------------------------------------
Class Name: WeatherReportSteps
Description: This java class will collate & organize all the steps that are to be implemented as part of 'Weather Forecast' and
captures test evidences without additional piece of code, Serenity default features supports this.
Date of Creation: 14/04/2020
Extends: NA
Implements: NA
Author: Leela, Sriram
-------------------------------------------------------------------------
Update Log: Newly designed and implemented for the technical test project
Date:14/04/2020 By:Leela, Sriram Details: No further updates
------------------------------------------------------------------------*/

package steps;

import java.util.Date;
import org.junit.Assert;
import org.openqa.selenium.By;

import commonReusable.Utilities;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.reports.adaptors.specflow.ScenarioStep;
import net.thucydides.core.steps.ScenarioSteps;
import pages.ContactPage;

public class ContactSteps extends ScenarioSteps {

	ContactPage contactPage;
	
	static Utilities util;
	
	
	
	 /**----------------------------------------------------------------------
    Method Name: getData()
    Description: This method is robust & reusable that can retrieve the required test data from xls file 
    Date of Creation: 29/04/2020
    Input Arguments: String getDataFor
    Return Parameters: void()
    Exception Used: e.getMessage()
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
	
	public String getData(String getDataFor) {

	return util.testData.get(getDataFor);

	}
	
	
	
	@Step
	public void launchPlanitTestingApplication() {
			contactPage.launchApplication();		
	}
	
	
	@Step
	public void fromthehomepagegotocontactpage() throws InterruptedException {
			contactPage.clickElement("contact");
		
	}
	
	
	@Step
	public void clickOnSubmitButton() throws InterruptedException {
			contactPage.clickElement("submit");
		
	}
	
	
	
	@Step
	public void validateErrors() throws InterruptedException {
			
			contactPage.elementIsDisplayed("foreNameError");
			contactPage.elementIsDisplayed("emailError");
			contactPage.elementIsDisplayed("messageError");
		
	}
	
	
	@Step
	public void populateMandatoryFields() throws InterruptedException {
		    contactPage.enterValueInto("forename", getData("Forename"));
			contactPage.enterValueInto("email", getData("Email"));
			contactPage.enterValueInto("message", getData("Message"));
		
	}
	
	
	@Step
	public void validateErrorsAreGone() throws InterruptedException {
			contactPage.elementNotToDisplayed("foreNameError");
			contactPage.elementNotToDisplayed("emailError");
			contactPage.elementNotToDisplayed("messageError");
		
	}
	
	
	@Step
	public void verifySuccessMessage() throws InterruptedException {
			contactPage.verifySuccessMessage("successMsg");
			
	}
	

	@Step
	public void validateInvalidErrors() throws InterruptedException {
			
			contactPage.elementIsDisplayed("foreNameError");
			contactPage.elementIsDisplayed("validEmail");
			contactPage.clickElement("submit");
			contactPage.elementIsDisplayed("messageError");
		
	}
	
	

	@Step
	public void ClickOnElement(String element) throws InterruptedException {
			contactPage.clickElement(element);
			
	}
	
	
	 /**----------------------------------------------------------------------
    Method Name: buyItems()
    Description: This method is reusable method to buy items that can be added to cart with Item & Quantity combinations
    Date of Creation: 29/04/2020
    Input Arguments: NA
    Return Parameters: void()    
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
	
	@Step
	public void buyItems() throws InterruptedException {

		String[] buyItems = getData("BuyItems").split("%");

		for (int i = 0; i < buyItems.length; i++) {

			String[] quantity = buyItems[i].split(",");

			for (int j = 0; j < quantity.length; j++) {

				if (j == 1) {

					int val = Integer.parseInt(quantity[j]);

					for (int j2 = 1; j2 <= val; j2++) {

						getDriver().findElement(By.xpath("//h4[text()='" + quantity[0] + "']/..//a")).click();
						
						//Serenity.takeScreenshot();

					}
				}

			}

		}

	}
	
	
	 /**----------------------------------------------------------------------
    Method Name: verifyCartItems()
    Description: This method is used to verify cart items added from list (test data)
    Date of Creation: 29/04/2020
    Input Arguments: NA
    Return Parameters: void()    
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
	
	@Step
	public void verifyCartItems() throws InterruptedException {
			
		String[] buyItems = getData("BuyItems").split("%");

		for (int i = 0; i < buyItems.length; i++) {

			String[] quantity = buyItems[i].split(",");

			for (int j = 0; j < quantity.length; j++) {

				if (j == 0) {
				

					getDriver().findElement(By.xpath("//td[text()=' " + quantity[0] + "']")).isDisplayed();
					
				}
			}
		}
		
			
	}
	
			

}
